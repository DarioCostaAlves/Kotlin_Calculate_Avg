package com.example.myappone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var oBotao: Button
    lateinit var aListaNumeros: EditText
    lateinit var oResultado: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        oBotao = findViewById(R.id.botao)
        aListaNumeros = findViewById(R.id.campoListaNumeros)
        oResultado = findViewById(R.id.campoResultado)
        oBotao.setOnClickListener {
            var s: String
            s = aListaNumeros.text.toString()
            calcularMaxMin(s)
        }
    }
    fun calcularMaxMin(s: String): Unit {
        var arrayNumeros = s.trim().split("\\s+".toRegex()).toTypedArray()
        var oMax : Float = -1.0F // valor irrelevante, só para contentar o compilador
        try {
            oMax = arrayNumeros[0].toFloat()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Aviso: valor inválido na lista foi ignorado", Toast.LENGTH_SHORT).show()
        }
        var oMin  = oMax
        for (k in 1 .. arrayNumeros.size-1) {
            var x: Float = -1.0F // valor irrelevante, só para contentar o compilador
            try {
                x = arrayNumeros[k].toFloat()
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Aviso: valor inválido na lista foi ignorado", Toast.LENGTH_SHORT).show()
            }
            if (x > oMax)
                oMax = x
            if (x < oMin)
                oMin = x
        }
        oResultado.setText("Max: $oMax, Min: $oMin")
    }
}